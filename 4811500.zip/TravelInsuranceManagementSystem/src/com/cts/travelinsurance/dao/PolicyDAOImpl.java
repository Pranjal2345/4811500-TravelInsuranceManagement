//package com.cts.travelinsurance.dao;
//
//
//import com.cts.travelinsurance.model.Policy;
//import com.cts.travelinsurance.util.DBConnection;
//
//import java.sql.*;
//import java.util.ArrayList;
//import java.util.List;
//
//public class PolicyDAOImpl implements PolicyDAO {
//
//    private static final String INSERT_POLICY_SQL = "INSERT INTO policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
//    private static final String SELECT_POLICY_BY_ID = "SELECT * FROM policy WHERE policy_id = ?";
//    private static final String SELECT_ALL_POLICIES = "SELECT * FROM policy";
//    private static final String UPDATE_POLICY_SQL = "UPDATE policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
//    private static final String DELETE_POLICY_SQL = "DELETE FROM policy WHERE policy_id = ?";
//
//    @Override
//    public void addPolicy(Policy policy) {
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_POLICY_SQL)) {
//
//            preparedStatement.setString(1, policy.getPolicyNumber());
//            preparedStatement.setString(2, policy.getType());
//            preparedStatement.setDouble(3, policy.getCoverageAmount());
//            preparedStatement.setDouble(4, policy.getPremiumAmount());
//
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error adding policy: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public Policy getPolicyById(int policyId) {
//        Policy policy = null;
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_POLICY_BY_ID)) {
//
//            preparedStatement.setInt(1, policyId);
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            if (resultSet.next()) {
//                policy = new Policy(
//                                                resultSet.getString("policy_number"),
//                        resultSet.getString("type"),
//                        resultSet.getDouble("coverage_amount"),
//                        resultSet.getDouble("premium_amount")
//                );
//            }
//        } catch (SQLException e) {
//            System.out.println("Error fetching policy: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return policy;
//    }
//
//    @Override
//    public List<Policy> getAllPolicies() {
//        List<Policy> policies = new ArrayList<>();
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_POLICIES);
//             ResultSet resultSet = preparedStatement.executeQuery()) {
//
//            while (resultSet.next()) {
//                policies.add(new Policy(
//                                                resultSet.getString("policy_number"),
//                        resultSet.getString("type"),
//                        resultSet.getDouble("coverage_amount"),
//                        resultSet.getDouble("premium_amount")
//                ));
//            }
//        } catch (SQLException e) {
//            System.out.println("Error fetching all policies: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return policies;
//    }
//
//    @Override
//    public void updatePolicy(Policy policy) {
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_POLICY_SQL)) {
//
//            preparedStatement.setString(1, policy.getPolicyNumber());
//            preparedStatement.setString(2, policy.getType());
//            preparedStatement.setDouble(3, policy.getCoverageAmount());
//            preparedStatement.setDouble(4, policy.getPremiumAmount());
//            preparedStatement.setInt(5, policy.getPolicyId());
//
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error updating policy: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public void deletePolicy(int policyId) {
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_POLICY_SQL)) {
//
//            preparedStatement.setInt(1, policyId);
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error deleting policy: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//}



package com.cts.travelinsurance.dao;

import com.cts.travelinsurance.model.Policy;
import com.cts.travelinsurance.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PolicyDAOImpl implements PolicyDAO {

    private static final String INSERT_POLICY_SQL = "INSERT INTO policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
    private static final String SELECT_POLICY_BY_ID = "SELECT * FROM policy WHERE policy_id = ?";
    private static final String SELECT_ALL_POLICIES = "SELECT * FROM policy";
    private static final String UPDATE_POLICY_SQL = "UPDATE policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
    private static final String DELETE_POLICY_SQL = "DELETE FROM policy WHERE policy_id = ?";

    @Override
    public int addPolicy(Policy policy) {
        int generatedPolicyId = -1;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_POLICY_SQL, Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setString(1, policy.getPolicyNumber());
            preparedStatement.setString(2, policy.getType());
            preparedStatement.setDouble(3, policy.getCoverageAmount());
            preparedStatement.setDouble(4, policy.getPremiumAmount());

            int affectedRows = preparedStatement.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        generatedPolicyId = generatedKeys.getInt(1);
                    }
                }
            }

        } catch (SQLException e) {
            System.out.println("Error adding policy: " + e.getMessage());
            e.printStackTrace();
        }
        return generatedPolicyId;
    }

    @Override
    public Policy getPolicyById(int policyId) {
        Policy policy = null;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_POLICY_BY_ID)) {

            preparedStatement.setInt(1, policyId);
            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    policy = new Policy(
                            policyId,  // Include the policy ID when creating the Policy object
                            resultSet.getString("policy_number"),
                            resultSet.getString("type"),
                            resultSet.getDouble("coverage_amount"),
                            resultSet.getDouble("premium_amount")
                    );
                }
            }
        } catch (SQLException e) {
            System.out.println("Error fetching policy: " + e.getMessage());
            e.printStackTrace();
        }
        return policy;
    }

    public List<Policy> getAllPolicies() {
        List<Policy> policies = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_POLICIES);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                policies.add(new Policy(
                        resultSet.getInt("policy_id"),  // Include the policy ID
                        resultSet.getString("policy_number"),
                        resultSet.getString("type"),
                        resultSet.getDouble("coverage_amount"),
                        resultSet.getDouble("premium_amount")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching all policies: " + e.getMessage());
            e.printStackTrace();
        }
        return policies;
    }

    @Override
    public void updatePolicy(Policy policy) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_POLICY_SQL)) {

            preparedStatement.setString(1, policy.getPolicyNumber());
            preparedStatement.setString(2, policy.getType());
            preparedStatement.setDouble(3, policy.getCoverageAmount());
            preparedStatement.setDouble(4, policy.getPremiumAmount());
            preparedStatement.setInt(5, policy.getPolicyId());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error updating policy: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Override
    public void deletePolicy(int policyId) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_POLICY_SQL)) {

            preparedStatement.setInt(1, policyId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error deleting policy: " + e.getMessage());
            e.printStackTrace();
        }
    }

   
}
