//package com.cts.travelinsurance.dao;
//
//import com.cts.travelinsurance.dao.ClaimDAO;
//import com.cts.travelinsurance.model.Claim;
//import com.cts.travelinsurance.util.DBConnection;
//
//import java.sql.*;
//import java.util.ArrayList;
//import java.util.List;
//
//public class ClaimDAOImpl implements ClaimDAO {
//
//    private static final String INSERT_CLAIM_SQL = "INSERT INTO claim (policy_id, traveler_id, claim_date, status) VALUES (?, ?, ?, ?)";
//    private static final String SELECT_CLAIM_BY_ID = "SELECT * FROM claim WHERE claim_id = ?";
//    private static final String SELECT_ALL_CLAIMS = "SELECT * FROM claim";
//    private static final String UPDATE_CLAIM_SQL = "UPDATE claim SET policy_id = ?, traveler_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
//    private static final String DELETE_CLAIM_SQL = "DELETE FROM claim WHERE claim_id = ?";
//
//    @Override
//    public void addClaim(Claim claim) {
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CLAIM_SQL)) {
//
//            preparedStatement.setInt(1, claim.getPolicyId());
//            preparedStatement.setInt(2, claim.getTravelerId());
//          
//            preparedStatement.setString(4, claim.getStatus());
//
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error adding claim: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public Claim getClaimById(int claimId) {
//        Claim claim = null;
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_CLAIM_BY_ID)) {
//
//            preparedStatement.setInt(1, claimId);
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            if (resultSet.next()) {
//                claim = new Claim(
//                        resultSet.getInt("claim_id"),
//                        resultSet.getInt("policy_id"),
//                        resultSet.getInt("traveler_id"),
//                        resultSet.getString("status")
//                );
//            }
//        } catch (SQLException e) {
//            System.out.println("Error fetching claim: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return claim;
//    }
//
//    @Override
//    public List<Claim> getAllClaims() {
//        List<Claim> claims = new ArrayList<>();
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_CLAIMS);
//             ResultSet resultSet = preparedStatement.executeQuery()) {
//
//            while (resultSet.next()) {
//                claims.add(new Claim(
//                        resultSet.getInt("claim_id"),
//                        resultSet.getInt("policy_id"),
//                        resultSet.getInt("traveler_id"),
//                       
//                        resultSet.getString("status")
//                ));
//            }
//        } catch (SQLException e) {
//            System.out.println("Error fetching all claims: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return claims;
//    }
//
//    @Override
//    public void updateClaim(Claim claim) {
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_CLAIM_SQL)) {
//
//            preparedStatement.setInt(1, claim.getPolicyId());
//            preparedStatement.setInt(2, claim.getTravelerId());
//        
//            preparedStatement.setString(4, claim.getStatus());
//            preparedStatement.setInt(5, claim.getClaimId());
//
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error updating claim: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public void deleteClaim(int claimId) {
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_CLAIM_SQL)) {
//
//            preparedStatement.setInt(1, claimId);
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error deleting claim: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//}


//package com.cts.travelinsurance.dao;
//
//import com.cts.travelinsurance.dao.ClaimDAO;
//import com.cts.travelinsurance.model.Claim;
//import com.cts.travelinsurance.util.DBConnection;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//public class ClaimDAOImpl implements ClaimDAO {
//
//    @Override
//    public void addClaim(Claim claim) {
//        String query = "INSERT INTO Claim (policy_id, traveler_id, claim_date, status) VALUES (?, ?, ?, ?)";
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query)) {
//
//            // Set the parameters for the prepared statement
//            statement.setInt(1, claim.getPolicyId());
//            statement.setInt(2, claim.getTravelerId());
//            statement.setString(3, claim.getClaimDate()); // Storing the date as a string
//            statement.setString(4, claim.getStatus());
//
//            // Execute the insert query
//            int rowsAffected = statement.executeUpdate();
//
//            if (rowsAffected > 0) {
//                System.out.println("Claim added successfully!");
//            } else {
//                System.out.println("Failed to add the claim.");
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error adding claim: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public Claim getClaimById(int claimId) {
//        String query = "SELECT * FROM Claim WHERE claim_id = ?";
//        Claim claim = null;
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query)) {
//
//            statement.setInt(1, claimId);
//
//            try (ResultSet resultSet = statement.executeQuery()) {
//                if (resultSet.next()) {
//                    int policyId = resultSet.getInt("policy_id");
//                    int travelerId = resultSet.getInt("traveler_id");
//                    String claimDate = resultSet.getString("claim_date"); // Retrieving the date as a string
//                    String status = resultSet.getString("status");
//
//                    claim = new Claim(claimId, policyId, travelerId, claimDate, status);
//                }
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error retrieving claim: " + e.getMessage());
//            e.printStackTrace();
//        }
//
//        return claim;
//    }
//
//    @Override
//    public void updateClaim(Claim claim) {
//        String query = "UPDATE Claim SET policy_id = ?, traveler_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query)) {
//
//            // Set the parameters for the prepared statement
//            statement.setInt(1, claim.getPolicyId());
//            statement.setInt(2, claim.getTravelerId());
//            statement.setString(3, claim.getClaimDate()); // Storing the date as a string
//            statement.setString(4, claim.getStatus());
//            statement.setInt(5, claim.getClaimId());
//
//            // Execute the update query
//            int rowsAffected = statement.executeUpdate();
//
//            if (rowsAffected > 0) {
//                System.out.println("Claim updated successfully!");
//            } else {
//                System.out.println("Failed to update the claim.");
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error updating claim: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public void deleteClaim(int claimId) {
//        String query = "DELETE FROM Claim WHERE claim_id = ?";
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query)) {
//
//            statement.setInt(1, claimId);
//
//            // Execute the delete query
//            int rowsAffected = statement.executeUpdate();
//
//            if (rowsAffected > 0) {
//                System.out.println("Claim deleted successfully!");
//            } else {
//                System.out.println("Failed to delete the claim.");
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error deleting claim: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public List<Claim> getAllClaims() {
//        String query = "SELECT * FROM Claim";
//        List<Claim> claims = new ArrayList<>();
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query);
//             ResultSet resultSet = statement.executeQuery()) {
//
//            while (resultSet.next()) {
//                int claimId = resultSet.getInt("claim_id");
//                int policyId = resultSet.getInt("policy_id");
//                int travelerId = resultSet.getInt("traveler_id");
//                String claimDate = resultSet.getString("claim_date"); // Retrieving the date as a string
//                String status = resultSet.getString("status");
//
//                Claim claim = new Claim(claimId, policyId, travelerId, claimDate, status);
//                claims.add(claim);
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error retrieving claims: " + e.getMessage());
//            e.printStackTrace();
//        }
//
//        return claims;
//    }
//}
//


package com.cts.travelinsurance.dao;

import com.cts.travelinsurance.model.Claim;
import com.cts.travelinsurance.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClaimDAOImpl implements ClaimDAO {

    private static final String INSERT_CLAIM_SQL = "INSERT INTO claim (policy_id, traveler_id, claim_date, status) VALUES (?, ?, ?, ?)";
    private static final String SELECT_CLAIM_BY_ID = "SELECT * FROM claim WHERE claim_id = ?";
    private static final String SELECT_ALL_CLAIMS = "SELECT * FROM claim";
    private static final String UPDATE_CLAIM_SQL = "UPDATE claim SET policy_id = ?, traveler_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
    private static final String DELETE_CLAIM_SQL = "DELETE FROM claim WHERE claim_id = ?";

    @Override
    public int addClaim(Claim claim) {
        int generatedId = -1;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CLAIM_SQL, Statement.RETURN_GENERATED_KEYS)) {

            preparedStatement.setInt(1, claim.getPolicyId());
            preparedStatement.setInt(2, claim.getTravelerId());
            preparedStatement.setString(3, claim.getClaimDate());
            preparedStatement.setString(4, claim.getStatus());

            preparedStatement.executeUpdate();
            
            ResultSet rs = preparedStatement.getGeneratedKeys();
            if (rs.next()) {
                generatedId = rs.getInt(1);
            }
        } catch (SQLException e) {
            System.out.println("Error adding claim: " + e.getMessage());
            e.printStackTrace();
        }
        return generatedId;
    }

    @Override
    public Claim getClaimById(int claimId) {
        Claim claim = null;
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_CLAIM_BY_ID)) {

            preparedStatement.setInt(1, claimId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                claim = new Claim(
                        resultSet.getInt("claim_id"),
                        resultSet.getInt("policy_id"),
                        resultSet.getInt("traveler_id"),
                        resultSet.getString("claim_date"),
                        resultSet.getString("status")
                );
            }
        } catch (SQLException e) {
            System.out.println("Error fetching claim: " + e.getMessage());
        }
        return claim;
    }

    @Override
    public List<Claim> getAllClaims() {
        List<Claim> claims = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_CLAIMS);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                claims.add(new Claim(
                        resultSet.getInt("claim_id"),
                        resultSet.getInt("policy_id"),
                        resultSet.getInt("traveler_id"),
                        resultSet.getString("claim_date"),
                        resultSet.getString("status")
                ));
            }
        } catch (SQLException e) {
            System.out.println("Error fetching all claims: " + e.getMessage());
        }
        return claims;
    }

    @Override
    public void updateClaim(Claim claim) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_CLAIM_SQL)) {

            preparedStatement.setInt(1, claim.getPolicyId());
            preparedStatement.setInt(2, claim.getTravelerId());
            preparedStatement.setString(3, claim.getClaimDate());
            preparedStatement.setString(4, claim.getStatus());
            preparedStatement.setInt(5, claim.getClaimId());

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error updating claim: " + e.getMessage());
        }
    }

    @Override
    public void deleteClaim(int claimId) {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_CLAIM_SQL)) {

            preparedStatement.setInt(1, claimId);
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            System.out.println("Error deleting claim: " + e.getMessage());
        }
    }
}
