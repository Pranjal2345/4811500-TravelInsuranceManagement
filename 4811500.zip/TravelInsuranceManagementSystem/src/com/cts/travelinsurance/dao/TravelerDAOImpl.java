//package com.cts.travelinsurance.dao;
//
//import com.cts.travelinsurance.dao.TravelerDAO;
//import com.cts.travelinsurance.model.Traveler;
//import com.cts.travelinsurance.util.DBConnection;
//
//import java.sql.*;
//import java.util.ArrayList;
//import java.util.List;
//
//public class TravelerDAOImpl implements TravelerDAO {
//
//    private static final String INSERT_TRAVELER_SQL = "INSERT INTO traveler (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
//    private static final String SELECT_TRAVELER_BY_ID = "SELECT * FROM traveler WHERE traveler_id = ?";
//    private static final String SELECT_ALL_TRAVELERS = "SELECT * FROM traveler";
//    private static final String UPDATE_TRAVELER_SQL = "UPDATE traveler SET name = ?, email = ?, phone_number = ?, address = ? WHERE traveler_id = ?";
//    private static final String DELETE_TRAVELER_SQL = "DELETE FROM traveler WHERE traveler_id = ?";
//
//    @Override
//    public void addTraveler(Traveler traveler) {
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_TRAVELER_SQL)) {
//
//            preparedStatement.setString(1, traveler.getName());
//            preparedStatement.setString(2, traveler.getEmail());
//            preparedStatement.setString(3, traveler.getPhoneNumber());
//            preparedStatement.setString(4, traveler.getAddress());
//
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error adding traveler: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public Traveler getTravelerById(int travelerId) {
//        Traveler traveler = null;
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_TRAVELER_BY_ID)) {
//
//            preparedStatement.setInt(1, travelerId);
//            ResultSet resultSet = preparedStatement.executeQuery();
//
//            if (resultSet.next()) {
//                traveler = new Traveler(
//                                                resultSet.getString("name"),
//                        resultSet.getString("email"),
//                        resultSet.getString("phone_number"),
//                        resultSet.getString("address")
//                );
//            }
//        } catch (SQLException e) {
//            System.out.println("Error fetching traveler: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return traveler;
//    }
//
//    @Override
//    public List<Traveler> getAllTravelers() {
//        List<Traveler> travelers = new ArrayList<>();
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_TRAVELERS);
//             ResultSet resultSet = preparedStatement.executeQuery()) {
//
//            while (resultSet.next()) {
//                travelers.add(new Traveler(
//                                                resultSet.getString("name"),
//                        resultSet.getString("email"),
//                        resultSet.getString("phone_number"),
//                        resultSet.getString("address")
//                ));
//            }
//        } catch (SQLException e) {
//            System.out.println("Error fetching all travelers: " + e.getMessage());
//            e.printStackTrace();
//        }
//        return travelers;
//    }
//
//    @Override
//    public void updateTraveler(Traveler traveler) {
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_TRAVELER_SQL)) {
//
//            preparedStatement.setString(1, traveler.getName());
//            preparedStatement.setString(2, traveler.getEmail());
//            preparedStatement.setString(3, traveler.getPhoneNumber());
//            preparedStatement.setString(4, traveler.getAddress());
//            preparedStatement.setInt(5, traveler.getTravelerId());
//
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error updating traveler: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public void deleteTraveler(int travelerId) {
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_TRAVELER_SQL)) {
//
//            preparedStatement.setInt(1, travelerId);
//            preparedStatement.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error deleting traveler: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//}












































//package com.cts.travelinsurance.dao;
//
//import com.cts.travelinsurance.dao.TravelerDAO;
//import com.cts.travelinsurance.model.Traveler;
//import com.cts.travelinsurance.util.DBConnection;
//
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.util.ArrayList;
//import java.util.List;
//
//public class TravelerDAOImpl implements TravelerDAO {
//
//    @Override
//    public void addTraveler(Traveler traveler) {
//        String query = "INSERT INTO Traveler (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query)) {
//
//            // Set the parameters for the prepared statement
//            statement.setString(1, traveler.getName());
//            statement.setString(2, traveler.getEmail());
//            statement.setString(3, traveler.getPhoneNumber());
//            statement.setString(4, traveler.getAddress());
//
//            // Execute the insert query
//            int rowsAffected = statement.executeUpdate();
//
//            if (rowsAffected > 0) {
//                System.out.println("Traveler added successfully!");
//            } else {
//                System.out.println("Failed to add the traveler.");
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error adding traveler: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public Traveler getTravelerById(int travelerId) {
//        String query = "SELECT * FROM Traveler WHERE traveler_id = ?";
//        Traveler traveler = null;
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query)) {
//
//            statement.setInt(1, travelerId);
//
//            try (ResultSet resultSet = statement.executeQuery()) {
//                if (resultSet.next()) {
//                    String name = resultSet.getString("name");
//                    String email = resultSet.getString("email");
//                    String phoneNumber = resultSet.getString("phone_number");
//                    String address = resultSet.getString("address");
//
//                    traveler = new Traveler(travelerId, name, email, phoneNumber, address);
//                }
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error retrieving traveler: " + e.getMessage());
//            e.printStackTrace();
//        }
//
//        return traveler;
//    }
//
//    @Override
//    public void updateTraveler(Traveler traveler) {
//        String query = "UPDATE Traveler SET name = ?, email = ?, phone_number = ?, address = ? WHERE traveler_id = ?";
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query)) {
//
//            // Set the parameters for the prepared statement
//            statement.setString(1, traveler.getName());
//            statement.setString(2, traveler.getEmail());
//            statement.setString(3, traveler.getPhoneNumber());
//            statement.setString(4, traveler.getAddress());
//            statement.setInt(5, traveler.getTravelerId());
//
//            // Execute the update query
//            int rowsAffected = statement.executeUpdate();
//
//            if (rowsAffected > 0) {
//                System.out.println("Traveler updated successfully!");
//            } else {
//                System.out.println("Failed to update the traveler.");
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error updating traveler: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public void deleteTraveler(int travelerId) {
//        String query = "DELETE FROM Traveler WHERE traveler_id = ?";
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query)) {
//
//            statement.setInt(1, travelerId);
//
//            // Execute the delete query
//            int rowsAffected = statement.executeUpdate();
//
//            if (rowsAffected > 0) {
//                System.out.println("Traveler deleted successfully!");
//            } else {
//                System.out.println("Failed to delete the traveler.");
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error deleting traveler: " + e.getMessage());
//            e.printStackTrace();
//        }
//    }
//
//    @Override
//    public List<Traveler> getAllTravelers() {
//        String query = "SELECT * FROM Traveler";
//        List<Traveler> travelers = new ArrayList<>();
//
//        try (Connection connection = DBConnection.getConnection();
//             PreparedStatement statement = connection.prepareStatement(query);
//             ResultSet resultSet = statement.executeQuery()) {
//
//            while (resultSet.next()) {
//                int travelerId = resultSet.getInt("traveler_id");
//                String name = resultSet.getString("name");
//                String email = resultSet.getString("email");
//                String phoneNumber = resultSet.getString("phone_number");
//                String address = resultSet.getString("address");
//
//                Traveler traveler = new Traveler(travelerId, name, email, phoneNumber, address);
//                travelers.add(traveler);
//            }
//
//        } catch (SQLException e) {
//            System.out.println("Error retrieving travelers: " + e.getMessage());
//            e.printStackTrace();
//        }
//
//        return travelers;
//    }
//}









//package com.cts.travelinsurance.dao;
//
//import com.cts.travelinsurance.model.Traveler;
//import com.cts.travelinsurance.util.DBConnection;
//
//import java.sql.*;
//
//public class TravelerDAOImpl implements TravelerDAO {
//
//    @Override
//    public int addTraveler(Traveler traveler) {
//        int travelerId = -1;
//        String sql = "INSERT INTO Traveler (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
//
//            pstmt.setString(1, traveler.getName());
//            pstmt.setString(2, traveler.getEmail());
//            pstmt.setString(3, traveler.getPhoneNumber());
//            pstmt.setString(4, traveler.getAddress());
//
//            int affectedRows = pstmt.executeUpdate();
//
//            if (affectedRows > 0) {
//                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
//                    if (generatedKeys.next()) {
//                        travelerId = generatedKeys.getInt(1);
//                    }
//                }
//            }
//        } catch (SQLException e) {
//            System.out.println("Error adding traveler: " + e.getMessage());
//        }
//
//        return travelerId;  // Return the travelerId
//    }
//
//    @Override
//    public Traveler getTravelerById(int travelerId) {
//        Traveler traveler = null;
//        String sql = "SELECT * FROM Traveler WHERE traveler_id = ?";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(sql)) {
//
//            pstmt.setInt(1, travelerId);
//            ResultSet rs = pstmt.executeQuery();
//
//            if (rs.next()) {
//                traveler = new Traveler(
//                        rs.getInt("traveler_id"),
//                        rs.getString("name"),
//                        rs.getString("email"),
//                        rs.getString("phone_number"),
//                        rs.getString("address")
//                );
//            }
//        } catch (SQLException e) {
//            System.out.println("Error retrieving traveler: " + e.getMessage());
//        }
//
//        return traveler;
//    }
//
//    @Override
//    public void updateTraveler(Traveler traveler) {
//        String sql = "UPDATE Traveler SET email = ?, phone_number = ?, address = ? WHERE traveler_id = ?";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(sql)) {
//
//            pstmt.setString(1, traveler.getEmail());
//            pstmt.setString(2, traveler.getPhoneNumber());
//            pstmt.setString(3, traveler.getAddress());
//            pstmt.setInt(4, traveler.getTravelerId());
//
//            pstmt.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error updating traveler: " + e.getMessage());
//        }
//    }
//
//    @Override
//    public void deleteTraveler(int travelerId) {
//        String sql = "DELETE FROM Traveler WHERE traveler_id = ?";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(sql)) {
//
//            pstmt.setInt(1, travelerId);
//            pstmt.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error deleting traveler: " + e.getMessage());
//        }
//    }
//}





//package com.cts.travelinsurance.dao;
//
//import com.cts.travelinsurance.model.Traveler;
//import com.cts.travelinsurance.util.DBConnection;
//
//import java.sql.*;
//import java.util.ArrayList;
//import java.util.List;
//
//public class TravelerDAOImpl implements TravelerDAO {
//
//    @Override
//    public int addTraveler(Traveler traveler) {
//        int travelerId = -1;
//        String sql = "INSERT INTO Traveler (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
//
//            pstmt.setString(1, traveler.getName());
//            pstmt.setString(2, traveler.getEmail());
//            pstmt.setString(3, traveler.getPhoneNumber());
//            pstmt.setString(4, traveler.getAddress());
//
//            int affectedRows = pstmt.executeUpdate();
//
//            if (affectedRows > 0) {
//                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
//                    if (generatedKeys.next()) {
//                        travelerId = generatedKeys.getInt(1);
//                    }
//                }
//            }
//        } catch (SQLException e) {
//            System.out.println("Error adding traveler: " + e.getMessage());
//        }
//
//        return travelerId;  // Return the travelerId
//    }
//
//    @Override
//    public Traveler getTravelerById(int travelerId) {
//        Traveler traveler = null;
//        String sql = "SELECT * FROM Traveler WHERE traveler_id = ?";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(sql)) {
//
//            pstmt.setInt(1, travelerId);
//            ResultSet rs = pstmt.executeQuery();
//
//            if (rs.next()) {
//                traveler = new Traveler(
//                        rs.getInt("traveler_id"),
//                        rs.getString("name"),
//                        rs.getString("email"),
//                        rs.getString("phone_number"),
//                        rs.getString("address")
//                );
//            }
//        } catch (SQLException e) {
//            System.out.println("Error retrieving traveler: " + e.getMessage());
//        }
//
//        return traveler;
//    }
//
//    @Override
//    public void updateTraveler(Traveler traveler) {
//        String sql = "UPDATE Traveler SET email = ?, phone_number = ?, address = ? WHERE traveler_id = ?";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(sql)) {
//
//            pstmt.setString(1, traveler.getEmail());
//            pstmt.setString(2, traveler.getPhoneNumber());
//            pstmt.setString(3, traveler.getAddress());
//            pstmt.setInt(4, traveler.getTravelerId());
//
//            pstmt.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error updating traveler: " + e.getMessage());
//        }
//    }
//
//    @Override
//    public void deleteTraveler(int travelerId) {
//        String sql = "DELETE FROM Traveler WHERE traveler_id = ?";
//
//        try (Connection conn = DBConnection.getConnection();
//             PreparedStatement pstmt = conn.prepareStatement(sql)) {
//
//            pstmt.setInt(1, travelerId);
//            pstmt.executeUpdate();
//        } catch (SQLException e) {
//            System.out.println("Error deleting traveler: " + e.getMessage());
//        }
//    }
//
//    @Override
//    public List<Traveler> getAllTravelers() {
//        List<Traveler> travelers = new ArrayList<>();
//        String sql = "SELECT * FROM Traveler";
//
//        try (Connection conn = DBConnection.getConnection();
//             Statement stmt = conn.createStatement();
//             ResultSet rs = stmt.executeQuery(sql)) {
//
//            while (rs.next()) {
//                Traveler traveler = new Traveler(
//                        rs.getInt("traveler_id"),
//                        rs.getString("name"),
//                        rs.getString("email"),
//                        rs.getString("phone_number"),
//                        rs.getString("address")
//                );
//                travelers.add(traveler);
//            }
//        } catch (SQLException e) {
//            System.out.println("Error listing travelers: " + e.getMessage());
//        }
//
//        return travelers;
//    }
//}




package com.cts.travelinsurance.dao;

import com.cts.travelinsurance.exception.TravelerNotFoundException;
import com.cts.travelinsurance.model.Traveler;
import com.cts.travelinsurance.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TravelerDAOImpl implements TravelerDAO {

    private static final String INSERT_TRAVELER_SQL = "INSERT INTO Traveler (name, email, phone_number, address) VALUES (?, ?, ?, ?)";
    private static final String SELECT_TRAVELER_BY_ID = "SELECT * FROM Traveler WHERE traveler_id = ?";
    private static final String UPDATE_TRAVELER_SQL = "UPDATE Traveler SET email = ?, phone_number = ?, address = ? WHERE traveler_id = ?";
    private static final String DELETE_TRAVELER_SQL = "DELETE FROM Traveler WHERE traveler_id = ?";
    private static final String SELECT_ALL_TRAVELERS = "SELECT * FROM Traveler";

    @Override
    public int addTraveler(Traveler traveler) {
        int travelerId = -1;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(INSERT_TRAVELER_SQL, Statement.RETURN_GENERATED_KEYS)) {

            pstmt.setString(1, traveler.getName());
            pstmt.setString(2, traveler.getEmail());
            pstmt.setString(3, traveler.getPhoneNumber());
            pstmt.setString(4, traveler.getAddress());

            int affectedRows = pstmt.executeUpdate();

            if (affectedRows > 0) {
                try (ResultSet generatedKeys = pstmt.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        travelerId = generatedKeys.getInt(1);
                    }
                }
            }
        } catch (SQLException e) {
            System.out.println("Error adding traveler: " + e.getMessage());
        }

        return travelerId;
    }

    @Override
    public Traveler getTravelerById(int travelerId) throws TravelerNotFoundException {
        Traveler traveler = null;
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(SELECT_TRAVELER_BY_ID)) {

            pstmt.setInt(1, travelerId);
            ResultSet rs = pstmt.executeQuery();

            if (rs.next()) {
                traveler = new Traveler(
                        rs.getInt("traveler_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone_number"),
                        rs.getString("address")
                );
            } else {
                throw new TravelerNotFoundException("Traveler with ID " + travelerId + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving traveler: " + e.getMessage());
        }

        return traveler;
    }

    @Override
    public void updateTraveler(Traveler traveler) throws TravelerNotFoundException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(UPDATE_TRAVELER_SQL)) {

            pstmt.setString(1, traveler.getEmail());
            pstmt.setString(2, traveler.getPhoneNumber());
            pstmt.setString(3, traveler.getAddress());
            pstmt.setInt(4, traveler.getTravelerId());

            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new TravelerNotFoundException("Traveler with ID " + traveler.getTravelerId() + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating traveler: " + e.getMessage());
        }
    }

    @Override
    public void deleteTraveler(int travelerId) throws TravelerNotFoundException {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(DELETE_TRAVELER_SQL)) {

            pstmt.setInt(1, travelerId);
            int affectedRows = pstmt.executeUpdate();
            if (affectedRows == 0) {
                throw new TravelerNotFoundException("Traveler with ID " + travelerId + " not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting traveler: " + e.getMessage());
        }
    }

    @Override
    public List<Traveler> getAllTravelers() {
        List<Traveler> travelers = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(SELECT_ALL_TRAVELERS)) {

            while (rs.next()) {
                Traveler traveler = new Traveler(
                        rs.getInt("traveler_id"),
                        rs.getString("name"),
                        rs.getString("email"),
                        rs.getString("phone_number"),
                        rs.getString("address")
                );
                travelers.add(traveler);
            }
        } catch (SQLException e) {
            System.out.println("Error listing travelers: " + e.getMessage());
        }

        return travelers;
    }
}
