//package com.cts.travelinsurance.dao;
//
//import com.cts.travelinsurance.model.Policy;
//import java.util.List;
//
//public interface PolicyDAO {
//    void addPolicy(Policy policy);
//    Policy getPolicyById(int policyId);
//    List<Policy> getAllPolicies();
//    void updatePolicy(Policy policy);
//    void deletePolicy(int policyId);
//}

package com.cts.travelinsurance.dao;

import com.cts.travelinsurance.model.Policy;
import java.util.List;

public interface PolicyDAO {
    int addPolicy(Policy policy);
    Policy getPolicyById(int policyId);
    void updatePolicy(Policy policy);
    void deletePolicy(int policyId);
    List<Policy> getAllPolicies(); // New method to list all policies

}
