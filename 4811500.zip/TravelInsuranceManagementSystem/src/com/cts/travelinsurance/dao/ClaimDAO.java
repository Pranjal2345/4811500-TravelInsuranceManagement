//package com.cts.travelinsurance.dao;
//
//import com.cts.travelinsurance.model.Claim;
//import java.util.List;
//
//public interface ClaimDAO {
//    void addClaim(Claim claim);
//    Claim getClaimById(int claimId);
//    List<Claim> getAllClaims();
//    void updateClaim(Claim claim);
//    void deleteClaim(int claimId);
//}

package com.cts.travelinsurance.dao;

import com.cts.travelinsurance.model.Claim;
import java.util.List;

public interface ClaimDAO {
    int addClaim(Claim claim);
    Claim getClaimById(int claimId);
    void updateClaim(Claim claim);
    void deleteClaim(int claimId);
    List<Claim> getAllClaims();
}
