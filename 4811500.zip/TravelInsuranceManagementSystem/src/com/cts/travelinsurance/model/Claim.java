//package com.cts.travelinsurance.model;
//
//import java.util.Date;
//
//public class Claim {
//
//    public Claim(int aInt, int aInt1, Date aInt2, String string) {
//    }
//    private int claimId;
//    private int policyId;
//    private int travelerId;
//    private Date claimDate;
//    private String status;
//
//    // Getter and Setter for claimId
//    public int getClaimId() {
//        return claimId;
//    }
//
//    public void setClaimId(int claimId) {
//        this.claimId = claimId;
//    }
//
//    // Getter and Setter for policyId
//    public int getPolicyId() {
//        return policyId;
//    }
//
//    public void setPolicyId(int policyId) {
//        this.policyId = policyId;
//    }
//
//    // Getter and Setter for travelerId
//    public int getTravelerId() {
//        return travelerId;
//    }
//
//    public void setTravelerId(int travelerId) {
//        this.travelerId = travelerId;
//    }
//
//    // Getter and Setter for claimDate
//    public Date getClaimDate() {
//        return claimDate;
//    }
//
//    public void setClaimDate(Date claimDate) {
//        this.claimDate = claimDate;
//    }
//
//    // Getter and Setter for status
//    public String getStatus() {
//        return status;
//    }
//
//    public void setStatus(String status) {
//        this.status = status;
//    }
//}
//


package com.cts.travelinsurance.model;

public class Claim {
    private int claimId;
    private int policyId;
    private int travelerId;
    private String claimDate; // Date stored as a formatted string
    private String status;

    // Constructor for new claims (without claimId)
    public Claim(int policyId, int travelerId, String claimDate, String status) {
        this.policyId = policyId;
        this.travelerId = travelerId;
        this.claimDate = claimDate;
        this.status = status;
    }

    // Constructor for claims retrieved from the database (with claimId)
    public Claim(int claimId, int policyId, int travelerId, String claimDate, String status) {
        this.claimId = claimId;
        this.policyId = policyId;
        this.travelerId = travelerId;
        this.claimDate = claimDate;
        this.status = status;
    }

    public Claim() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Getters and Setters
    public int getClaimId() {
        return claimId;
    }

    public void setClaimId(int claimId) {
        this.claimId = claimId;
    }

    public int getPolicyId() {
        return policyId;
    }

    public void setPolicyId(int policyId) {
        this.policyId = policyId;
    }

    public int getTravelerId() {
        return travelerId;
    }

    public void setTravelerId(int travelerId) {
        this.travelerId = travelerId;
    }

    public String getClaimDate() {
        return claimDate;
    }

    public void setClaimDate(String claimDate) {
        this.claimDate = claimDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

