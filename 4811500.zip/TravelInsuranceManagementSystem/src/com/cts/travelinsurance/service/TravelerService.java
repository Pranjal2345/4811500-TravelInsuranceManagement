package com.cts.travelinsurance.service;

import com.cts.travelinsurance.dao.TravelerDAO;
import com.cts.travelinsurance.exception.TravelerNotFoundException;
import com.cts.travelinsurance.model.Traveler;
import java.util.List;

public class TravelerService {
    private TravelerDAO travelerDAO;

    public TravelerService(TravelerDAO travelerDAO) {
        this.travelerDAO = travelerDAO;
    }

    public void addTraveler(Traveler traveler) {
        travelerDAO.addTraveler(traveler);
    }

    public Traveler getTravelerById(int travelerId) throws TravelerNotFoundException {
        Traveler traveler = travelerDAO.getTravelerById(travelerId);
        if (traveler == null) {
            throw new TravelerNotFoundException("Traveler with ID " + travelerId + " not found.");
        }
        return traveler;
    }

//    public List<Traveler> getAllTravelers() {
//        return travelerDAO.getAllTravelers();
//    }

    public void updateTraveler(Traveler traveler) throws TravelerNotFoundException {
        if (travelerDAO.getTravelerById(traveler.getTravelerId()) == null) {
            throw new TravelerNotFoundException("Traveler with ID " + traveler.getTravelerId() + " not found.");
        }
        travelerDAO.updateTraveler(traveler);
    }

    public void deleteTraveler(int travelerId) throws TravelerNotFoundException {
        if (travelerDAO.getTravelerById(travelerId) == null) {
            throw new TravelerNotFoundException("Traveler with ID " + travelerId + " not found.");
        }
        travelerDAO.deleteTraveler(travelerId);
    }
}
