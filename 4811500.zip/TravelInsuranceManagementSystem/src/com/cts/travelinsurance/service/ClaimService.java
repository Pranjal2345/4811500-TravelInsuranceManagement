package com.cts.travelinsurance.service;

import com.cts.travelinsurance.dao.ClaimDAO;
import com.cts.travelinsurance.exception.ClaimNotFoundException;
import com.cts.travelinsurance.model.Claim;
import java.util.List;

public class ClaimService {
    private ClaimDAO claimDAO;

    public ClaimService(ClaimDAO claimDAO) {
        this.claimDAO = claimDAO;
    }

    public void addClaim(Claim claim) {
        claimDAO.addClaim(claim);
    }

    public Claim getClaimById(int claimId) throws ClaimNotFoundException {
        Claim claim = claimDAO.getClaimById(claimId);
        if (claim == null) {
            throw new ClaimNotFoundException("Claim with ID " + claimId + " not found.");
        }
        return claim;
    }

    public List<Claim> getAllClaims() {
        return claimDAO.getAllClaims();
    }

    public void updateClaim(Claim claim) throws ClaimNotFoundException {
        if (claimDAO.getClaimById(claim.getClaimId()) == null) {
            throw new ClaimNotFoundException("Claim with ID " + claim.getClaimId() + " not found.");
        }
        claimDAO.updateClaim(claim);
    }

    public void deleteClaim(int claimId) throws ClaimNotFoundException {
        if (claimDAO.getClaimById(claimId) == null) {
            throw new ClaimNotFoundException("Claim with ID " + claimId + " not found.");
        }
        claimDAO.deleteClaim(claimId);
    }
}
