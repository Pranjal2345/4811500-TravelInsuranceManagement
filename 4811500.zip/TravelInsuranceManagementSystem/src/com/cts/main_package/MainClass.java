//   
package com.cts.main_package;
//import com.cts.travelinsurance.dao.ClaimDAO;
//import com.cts.travelinsurance.dao.ClaimDAOImpl;
//import com.cts.travelinsurance.dao.PolicyDAO;
//import com.cts.travelinsurance.dao.PolicyDAOImpl;
//import com.cts.travelinsurance.dao.TravelerDAO;
//import com.cts.travelinsurance.dao.TravelerDAOImpl;
//   import com.cts.travelinsurance.service.ClaimService;
//   import com.cts.travelinsurance.model.Policy;
//   import com.cts.travelinsurance.model.Traveler;
//   import com.cts.travelinsurance.model.Claim;
//   import com.cts.travelinsurance.exception.PolicyNotFoundException;
//   import com.cts.travelinsurance.exception.TravelerNotFoundException;
//   import com.cts.travelinsurance.exception.ClaimNotFoundException;
//import com.cts.travelinsurance.service.PolicyService;
//import com.cts.travelinsurance.service.TravelerService;
//
//   import java.util.Scanner;
//   import java.util.List;
//
//   public class MainClass {
//       private PolicyService policyService;
//       private TravelerService travelerService;
//       private ClaimService claimService;
//       private Scanner scanner;
//
//       public MainClass(PolicyService policyService, TravelerService travelerService, ClaimService claimService) {
//           this.policyService = policyService;
//           this.travelerService = travelerService;
//           this.claimService = claimService;
//           this.scanner = new Scanner(System.in);
//       }
//
//       public void start() {
//           while (true) {
//               System.out.println("---- Travel Insurance Management System ----");
//               System.out.println("1. Manage Policies");
//               System.out.println("2. Manage Travelers");
//               System.out.println("3. Manage Claims");
//               System.out.println("4. Exit");
//               System.out.print("Choose an option: ");
//               int choice = scanner.nextInt();
//
//               switch (choice) {
//                   case 1:
//                       managePolicies();
//                       break;
//                   case 2:
//                       manageTravelers();
//                       break;
//                   case 3:
//                       manageClaims();
//                       break;
//                   case 4:
//                       System.out.println("Exiting the system.");
//                       return;
//                   default:
//                       System.out.println("Invalid option. Please try again.");
//               }
//           }
//       }
//
//       private void managePolicies() {
//           while (true) {
//               System.out.println("---- Policy Management ----");
//               System.out.println("1. Add a new Policy");
//               System.out.println("2. View Policy Details");
//               System.out.println("3. Update Policy Information");
//               System.out.println("4. Delete a Policy");
//               System.out.println("5. Back to Main Menu");
//               System.out.print("Choose an option: ");
//               int choice = scanner.nextInt();
//
//               switch (choice) {
//                   case 1:
//                       addPolicy();
//                       break;
//                   case 2:
//                       viewPolicyDetails();
//                       break;
//                   case 3:
//                       updatePolicy();
//                       break;
//                   case 4:
//                       deletePolicy();
//                       break;
//                   case 5:
//                       return;
//                   default:
//                       System.out.println("Invalid option. Please try again.");
//               }
//           }
//       }
//
//       private void addPolicy() {
//           System.out.println("Enter policy details:");
//           System.out.print("Policy Number: ");
//           String policyNumber = scanner.next();
//           System.out.print("Type: ");
//           String type = scanner.next();
//           System.out.print("Coverage Amount: ");
//           double coverageAmount = scanner.nextDouble();
//           System.out.print("Premium Amount: ");
//           double premiumAmount = scanner.nextDouble();
//
//           Policy policy = new Policy();
//           policy.setPolicyNumber(policyNumber);
//           policy.setType(type);
//           policy.setCoverageAmount(coverageAmount);
//           policy.setPremiumAmount(premiumAmount);
//
//           policyService.addPolicy(policy);
//           System.out.println("Policy added successfully.");
//       }
//
//       private void viewPolicyDetails() {
//           System.out.print("Enter Policy ID: ");
//           int policyId = scanner.nextInt();
//
//           try {
//               Policy policy = policyService.getPolicyById(policyId);
//               System.out.println("Policy ID: " + policy.getPolicyId());
//               System.out.println("Policy Number: " + policy.getPolicyNumber());
//               System.out.println("Type: " + policy.getType());
//               System.out.println("Coverage Amount: " + policy.getCoverageAmount());
//               System.out.println("Premium Amount: " + policy.getPremiumAmount());
//           } catch (PolicyNotFoundException e) {
//               System.out.println(e.getMessage());
//           }
//       }
//
//       private void updatePolicy() {
//           System.out.print("Enter Policy ID: ");
//           int policyId = scanner.nextInt();
//
//           try {
//               Policy policy = policyService.getPolicyById(policyId);
//               System.out.println("Enter new details for the policy:");
//               System.out.print("Policy Number: ");
//               policy.setPolicyNumber(scanner.next());
//               System.out.print("Type: ");
//               policy.setType(scanner.next());
//               System.out.print("Coverage Amount: ");
//               policy.setCoverageAmount(scanner.nextDouble());
//               System.out.print("Premium Amount: ");
//               policy.setPremiumAmount(scanner.nextDouble());
//
//               policyService.updatePolicy(policy);
//               System.out.println("Policy updated successfully.");
//           } catch (PolicyNotFoundException e) {
//               System.out.println(e.getMessage());
//           }
//       }
//
//       private void deletePolicy() {
//           System.out.print("Enter Policy ID: ");
//           int policyId = scanner.nextInt();
//
//           try {
//               policyService.deletePolicy(policyId);
//               System.out.println("Policy deleted successfully.");
//           } catch (PolicyNotFoundException e) {
//               System.out.println(e.getMessage());
//           }
//       }
//
//       private void manageTravelers() {
//           while (true) {
//               System.out.println("---- Traveler Management ----");
//               System.out.println("1. Register a new Traveler");
//               System.out.println("2. View Traveler Details");
//               System.out.println("3. Update Traveler Information");
//               System.out.println("4. Delete a Traveler");
//               System.out.println("5. Back to Main Menu");
//               System.out.print("Choose an option: ");
//               int choice = scanner.nextInt();
//
//               switch (choice) {
//                   case 1:
//                       addTraveler();
//                       break;
//                   case 2:
//                       viewTravelerDetails();
//                       break;
//                   case 3:
//                       updateTraveler();
//                       break;
//                   case 4:
//                       deleteTraveler();
//                       break;
//                   case 5:
//                       return;
//                   default:
//                       System.out.println("Invalid option. Please try again.");
//               }
//           }
//       }
//
//       private void addTraveler() {
//           System.out.println("Enter traveler details:");
//           System.out.print("Name: ");
//           String name = scanner.next();
//           System.out.print("Email: ");
//           String email = scanner.next();
//           System.out.print("Phone Number: ");
//           String phoneNumber = scanner.next();
//           System.out.print("Address: ");
//           String address = scanner.next();
//
//           Traveler traveler = new Traveler();
//           traveler.setName(name);
//           traveler.setEmail(email);
//           traveler.setPhoneNumber(phoneNumber);
//           traveler.setAddress(address);
//
//           travelerService.addTraveler(traveler);
//           System.out.println("Traveler registered successfully.");
//       }
//
//       private void viewTravelerDetails() {
//           System.out.print("Enter Traveler ID: ");
//           int travelerId = scanner.nextInt();
//
//           try {
//               Traveler traveler = travelerService.getTravelerById(travelerId);
//               System.out.println("Traveler ID: " + traveler.getTravelerId());
//               System.out.println("Name: " + traveler.getName());
//               System.out.println("Email: " + traveler.getEmail());
//               System.out.println("Phone Number: " + traveler.getPhoneNumber());
//               System.out.println("Address: " + traveler.getAddress());
//           } catch (TravelerNotFoundException e) {
//               System.out.println(e.getMessage());
//           }
//       }
//
//       private void updateTraveler() {
//           System.out.print("Enter Traveler ID: ");
//           int travelerId = scanner.nextInt();
//
//           try {
//               Traveler traveler = travelerService.getTravelerById(travelerId);
//               System.out.println("Enter new details for the traveler:");
//               System.out.print("Name: ");
//               traveler.setName(scanner.next());
//               System.out.print("Email: ");
//               traveler.setEmail(scanner.next());
//               System.out.print("Phone Number: ");
//               traveler.setPhoneNumber(scanner.next());
//               System.out.print("Address: ");
//               traveler.setAddress(scanner.next());
//
//               travelerService.updateTraveler(traveler);
//               System.out.println("Traveler updated successfully.");
//           } catch (TravelerNotFoundException e) {
//               System.out.println(e.getMessage());
//           }
//       }
//
//       private void deleteTraveler() {
//           System.out.print("Enter Traveler ID: ");
//           int travelerId = scanner.nextInt();
//
//           try {
//               travelerService.deleteTraveler(travelerId);
//               System.out.println("Traveler deleted successfully.");
//           } catch (TravelerNotFoundException e) {
//               System.out.println(e.getMessage());
//           }
//       }
//
//       private void manageClaims() {
//           while (true) {
//               System.out.println("---- Claim Management ----");
//               System.out.println("1. Submit a new Claim");
//               System.out.println("2. View Claim Details");
//               System.out.println("3. Update Claim Information");
//               System.out.println("4. Delete a Claim");
//               System.out.println("5. Back to Main Menu");
//               System.out.print("Choose an option: ");
//               int choice = scanner.nextInt();
//
//               switch (choice) {
//                   case 1:
//                       submitClaim();
//                       break;
//                   case 2:
//                       viewClaimDetails();
//                       break;
//                   case 3:
//                       updateClaim();
//                       break;
//                   case 4:
//                       deleteClaim();
//                       break;
//                   case 5:
//                       return;
//                   default:
//                       System.out.println("Invalid option. Please try again.");
//               }
//           }
//       }
//
//       private void submitClaim() {
//           System.out.println("Enter claim details:");
//           System.out.print("Policy ID: ");
//           int policyId = scanner.nextInt();
//           System.out.print("Traveler ID: ");
//           int travelerId = scanner.nextInt();
//           System.out.print("Claim Date (YYYY-MM-DD): ");
//           String claimDate = scanner.next();
//           System.out.print("Status (submitted/processed): ");
//           String status = scanner.next();
//
//           Claim claim = new Claim();
//           claim.setPolicyId(policyId);
//           claim.setTravelerId(travelerId);
//           claim.setClaimDate(claimDate);
//           claim.setStatus(status);
//
//           claimService.addClaim(claim);
//           System.out.println("Claim submitted successfully.");
//       }
//
//       private void viewClaimDetails() {
//           System.out.print("Enter Claim ID: ");
//           int claimId = scanner.nextInt();
//
//           try {
//               Claim claim = claimService.getClaimById(claimId);
//               System.out.println("Claim ID: " + claim.getClaimId());
//               System.out.println("Policy ID: " + claim.getPolicyId());
//               System.out.println("Traveler ID: " + claim.getTravelerId());
//               System.out.println("Claim Date: " + claim.getClaimDate());
//               System.out.println("Status: " + claim.getStatus());
//           } catch (ClaimNotFoundException e) {
//               System.out.println(e.getMessage());
//           }
//       }
//
//       private void updateClaim() {
//           System.out.print("Enter Claim ID: ");
//           int claimId = scanner.nextInt();
//
//           try {
//               Claim claim = claimService.getClaimById(claimId);
//               System.out.println("Enter new details for the claim:");
//               System.out.print("Policy ID: ");
//               claim.setPolicyId(scanner.nextInt());
//               System.out.print("Traveler ID: ");
//               claim.setTravelerId(scanner.nextInt());
//               System.out.print("Claim Date (YYYY-MM-DD): ");
//               claim.setClaimDate(scanner.next());
//               System.out.print("Status (submitted/processed): ");
//               claim.setStatus(scanner.next());
//
//               claimService.updateClaim(claim);
//               System.out.println("Claim updated successfully.");
//           } catch (ClaimNotFoundException e) {
//               System.out.println(e.getMessage());
//           }
//       }
//
//       private void deleteClaim() {
//           System.out.print("Enter Claim ID: ");
//           int claimId = scanner.nextInt();
//
//           try {
//               claimService.deleteClaim(claimId);
//               System.out.println("Claim deleted successfully.");
//           } catch (ClaimNotFoundException e) {
//               System.out.println(e.getMessage());
//           }
//       }
//
//       public static void main(String[] args) {
//           PolicyDAO policyDAO = new PolicyDAOImpl(); // Replace with actual implementation
//           TravelerDAO travelerDAO = new TravelerDAOImpl(); // Replace with actual implementation
//           ClaimDAO claimDAO = new ClaimDAOImpl(); // Replace with actual implementation
//
//           PolicyService policyService = new PolicyService(policyDAO);
//           TravelerService travelerService = new TravelerService(travelerDAO);
//           ClaimService claimService = new ClaimService(claimDAO);
//
//           MainClass app = new MainClass(policyService, travelerService, claimService);
//           app.start();
//       }
//   }

import com.cts.travelinsurance.dao.PolicyDAO;
import com.cts.travelinsurance.dao.TravelerDAO;
import com.cts.travelinsurance.dao.ClaimDAO;
import com.cts.travelinsurance.dao.PolicyDAOImpl;
import com.cts.travelinsurance.dao.TravelerDAOImpl;
import com.cts.travelinsurance.dao.ClaimDAOImpl;
import com.cts.travelinsurance.exception.TravelerNotFoundException;
import com.cts.travelinsurance.model.Policy;
import com.cts.travelinsurance.model.Traveler;
import com.cts.travelinsurance.model.Claim;

import java.util.*;

public class MainClass {
    public static void main(String[] args) {
        PolicyDAO policyDAO = new PolicyDAOImpl();
         
        TravelerDAO travelerDAO = new TravelerDAOImpl();
        ClaimDAO claimDAO = new ClaimDAOImpl();

        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("===== Travel Insurance Management System =====");
            System.out.println("1. Policy Management");
            System.out.println("2. Traveler Management");
            System.out.println("3. Claim Management");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    managePolicies(policyDAO, scanner);
                    break;
                case 2:
                    manageTravelers(travelerDAO, scanner);
                    break;
                case 3:
                    manageClaims(claimDAO, scanner);
                    break;
                case 4:
                    System.out.println("Exiting...");
                    break;
                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        } while (choice != 4);

        scanner.close();
    }

//    private static void managePolicies(PolicyDAO policyDAO, Scanner scanner) {
//        System.out.println("===== Policy Management =====");
//        System.out.println("1. Add a new policy");
//        System.out.println("2. View policy details");
//        System.out.println("3. Update policy information");
//        System.out.println("4. Delete a policy");
//        System.out.print("Enter your choice: ");
//        int choice = scanner.nextInt();
//
//        switch (choice) {
//            case 1:
//                System.out.print("Enter Policy Number: ");
//                String policyNumber = scanner.next();
//                System.out.print("Enter Type: ");
//                String type = scanner.next();
//                System.out.print("Enter Coverage Amount: ");
//                double coverageAmount = scanner.nextDouble();
//                System.out.print("Enter Premium Amount: ");
//                double premiumAmount = scanner.nextDouble();
//
//                Policy newPolicy = new Policy(policyNumber, type, coverageAmount, premiumAmount);
//                policyDAO.addPolicy(newPolicy);
//                System.out.println("Policy added successfully!");
//                break;
//
//            case 2:
//                System.out.print("Enter Policy ID: ");
//                int policyId = scanner.nextInt();
//                Policy policy = policyDAO.getPolicyById(policyId);
//                if (policy != null) {
//                    System.out.println("Policy ID: " + policy.getPolicyId());
//                    System.out.println("Policy Number: " + policy.getPolicyNumber());
//                    System.out.println("Type: " + policy.getType());
//                    System.out.println("Coverage Amount: " + policy.getCoverageAmount());
//                    System.out.println("Premium Amount: " + policy.getPremiumAmount());
//                } else {
//                    System.out.println("Policy not found!");
//                }
//                break;
//
//            case 3:
//                System.out.print("Enter Policy ID to update: ");
//                policyId = scanner.nextInt();
//                policy = policyDAO.getPolicyById(policyId);
//                if (policy != null) {
//                    System.out.print("Enter new Coverage Amount: ");
//                    coverageAmount = scanner.nextDouble();
//                    System.out.print("Enter new Premium Amount: ");
//                    premiumAmount = scanner.nextDouble();
//
//                    policy.setCoverageAmount(coverageAmount);
//                    policy.setPremiumAmount(premiumAmount);
//
//                    policyDAO.updatePolicy(policy);
//                    System.out.println("Policy updated successfully!");
//                } else {
//                    System.out.println("Policy not found!");
//                }
//                break;
//
//            case 4:
//                System.out.print("Enter Policy ID to delete: ");
//                policyId = scanner.nextInt();
//                policyDAO.deletePolicy(policyId);
//                System.out.println("Policy deleted successfully!");
//                break;
//
//            default:
//                System.out.println("Invalid choice!");
//        }
//    }
//

    
    private static void managePolicies(PolicyDAO policyDAO, Scanner scanner) {
    System.out.println("===== Policy Management =====");
    System.out.println("1. Add a new policy");
    System.out.println("2. View policy details");
    System.out.println("3. Update policy information");
    System.out.println("4. Delete a policy");
    System.out.println("5. List all policies");
    System.out.print("Enter your choice: ");
    int choice = scanner.nextInt();

    switch (choice) {
        case 1:
            System.out.print("Enter Policy Number: ");
            String policyNumber = scanner.next();
            System.out.print("Enter Type: ");
            String type = scanner.next();
            System.out.print("Enter Coverage Amount: ");
            double coverageAmount = scanner.nextDouble();
            System.out.print("Enter Premium Amount: ");
            double premiumAmount = scanner.nextDouble();

            Policy newPolicy = new Policy(policyNumber, type, coverageAmount, premiumAmount);
            int policyId = policyDAO.addPolicy(newPolicy);
            System.out.println("Policy added successfully! Policy ID: " + policyId);
            break;

        case 2:
            System.out.print("Enter Policy ID: ");
            policyId = scanner.nextInt();
            Policy policy = policyDAO.getPolicyById(policyId);
            if (policy != null) {
                System.out.println("Policy ID: " + policy.getPolicyId());
                System.out.println("Policy Number: " + policy.getPolicyNumber());
                System.out.println("Type: " + policy.getType());
                System.out.println("Coverage Amount: " + policy.getCoverageAmount());
                System.out.println("Premium Amount: " + policy.getPremiumAmount());
            } else {
                System.out.println("Policy not found!");
            }
            break;

        case 3:
            System.out.print("Enter Policy ID to update: ");
            policyId = scanner.nextInt();
            policy = policyDAO.getPolicyById(policyId);
            if (policy != null) {
                System.out.print("Enter new Coverage Amount: ");
                coverageAmount = scanner.nextDouble();
                System.out.print("Enter new Premium Amount: ");
                premiumAmount = scanner.nextDouble();

                policy.setCoverageAmount(coverageAmount);
                policy.setPremiumAmount(premiumAmount);

                policyDAO.updatePolicy(policy);
                System.out.println("Policy updated successfully!");
            } else {
                System.out.println("Policy not found!");
            }
            break;

        case 4:
            System.out.print("Enter Policy ID to delete: ");
            policyId = scanner.nextInt();
            policyDAO.deletePolicy(policyId);
            System.out.println("Policy deleted successfully!");
            break;

        case 5:
            List<Policy> policies = policyDAO.getAllPolicies();
            if (policies.isEmpty()) {
                System.out.println("No policies found.");
            } else {
                for (Policy p : policies) {
                    System.out.println("Policy ID: " + p.getPolicyId() +
                                       ", Policy Number: " + p.getPolicyNumber() +
                                       ", Type: " + p.getType() +
                                       ", Coverage Amount: " + p.getCoverageAmount() +
                                       ", Premium Amount: " + p.getPremiumAmount());
                }
            }
            break;

        default:
            System.out.println("Invalid choice!");
    }
}


//private static void manageTravelers(TravelerDAO travelerDAO, Scanner scanner) {
//    System.out.println("===== Traveler Management =====");
//    System.out.println("1. Register a new traveler");
//    System.out.println("2. View traveler details");
//    System.out.println("3. Update traveler information");
//    System.out.println("4. Delete a traveler");
//    System.out.println("5. List all travelers");  // New option to list all travelers
//    System.out.print("Enter your choice: ");
//    int choice = scanner.nextInt();
//    scanner.nextLine();  // Consume newline
//
//    switch (choice) {
//        case 1:
//            System.out.print("Enter Name: ");
//            String name = scanner.nextLine();
//            System.out.print("Enter Email: ");
//            String email = scanner.nextLine();
//            System.out.print("Enter Phone Number: ");
//            String phoneNumber = scanner.nextLine();
//            System.out.print("Enter Address: ");
//            String address = scanner.nextLine();
//
//            Traveler newTraveler = new Traveler(name, email, phoneNumber, address);
//            int travelerId = travelerDAO.addTraveler(newTraveler);
//
//            if (travelerId > 0) {
//                System.out.println("Traveler registered successfully with ID: " + travelerId);
//            } else {
//                System.out.println("Error registering traveler.");
//            }
//            break;
//
//        case 2:
//            System.out.print("Enter Traveler ID: ");
//            int travelerIdToView = scanner.nextInt();
//            Traveler traveler = travelerDAO.getTravelerById(travelerIdToView);
//            if (traveler != null) {
//                System.out.println("Traveler ID: " + traveler.getTravelerId());
//                System.out.println("Name: " + traveler.getName());
//                System.out.println("Email: " + traveler.getEmail());
//                System.out.println("Phone Number: " + traveler.getPhoneNumber());
//                System.out.println("Address: " + traveler.getAddress());
//            } else {
//                System.out.println("Traveler not found!");
//            }
//            break;
//
//        case 3:
//            System.out.print("Enter Traveler ID to update: ");
//            int travelerIdToUpdate = scanner.nextInt();
//            scanner.nextLine();  // Consume newline
//            Traveler travelerToUpdate = travelerDAO.getTravelerById(travelerIdToUpdate);
//            if (travelerToUpdate != null) {
//                System.out.print("Enter new Email: ");
//                email = scanner.nextLine();
//                System.out.print("Enter new Phone Number: ");
//                phoneNumber = scanner.nextLine();
//                System.out.print("Enter new Address: ");
//                address = scanner.nextLine();
//
//                travelerToUpdate.setEmail(email);
//                travelerToUpdate.setPhoneNumber(phoneNumber);
//                travelerToUpdate.setAddress(address);
//
//                travelerDAO.updateTraveler(travelerToUpdate);
//                System.out.println("Traveler updated successfully!");
//            } else {
//                System.out.println("Traveler not found!");
//            }
//            break;
//
//        case 4:
//            System.out.print("Enter Traveler ID to delete: ");
//            int travelerIdToDelete = scanner.nextInt();
//            travelerDAO.deleteTraveler(travelerIdToDelete);
//            System.out.println("Traveler deleted successfully!");
//            break;
//
//        case 5:
//            List<Traveler> travelers = travelerDAO.getAllTravelers();
//            if (travelers.isEmpty()) {
//                System.out.println("No travelers found.");
//            } else {
//                System.out.println("===== List of Travelers =====");
//                for (Traveler t : travelers) {
//                    System.out.println("Traveler ID: " + t.getTravelerId());
//                    System.out.println("Name: " + t.getName());
//                    System.out.println("Email: " + t.getEmail());
//                    System.out.println("Phone Number: " + t.getPhoneNumber());
//                    System.out.println("Address: " + t.getAddress());
//                    System.out.println("-----------------------------");
//                }
//            }
//            break;
//
//        default:
//            System.out.println("Invalid choice!");
//    }
//}
    
    
    
    private static void manageTravelers(TravelerDAO travelerDAO, Scanner scanner) {
    System.out.println("===== Traveler Management =====");
    System.out.println("1. Register a new traveler");
    System.out.println("2. View traveler details");
    System.out.println("3. Update traveler information");
    System.out.println("4. Delete a traveler");
    System.out.println("5. List all travelers");
    System.out.print("Enter your choice: ");
    int choice = scanner.nextInt();

    try {
        switch (choice) {
            case 1:
                System.out.print("Enter Name: ");
                String name = scanner.next();
                System.out.print("Enter Email: ");
                String email = scanner.next();
                System.out.print("Enter Phone Number: ");
                String phoneNumber = scanner.next();
                System.out.print("Enter Address: ");
                String address = scanner.next();

                Traveler newTraveler = new Traveler(name, email, phoneNumber, address);
                int travelerId = travelerDAO.addTraveler(newTraveler);
                System.out.println("Traveler registered successfully! Traveler ID: " + travelerId);
                break;

            case 2:
                System.out.print("Enter Traveler ID: ");
                int travelerIdToView = scanner.nextInt();
                Traveler traveler = travelerDAO.getTravelerById(travelerIdToView);
                System.out.println("Traveler ID: " + traveler.getTravelerId());
                System.out.println("Name: " + traveler.getName());
                System.out.println("Email: " + traveler.getEmail());
                System.out.println("Phone Number: " + traveler.getPhoneNumber());
                System.out.println("Address: " + traveler.getAddress());
                break;

            case 3:
                System.out.print("Enter Traveler ID to update: ");
                int travelerIdToUpdate = scanner.nextInt();
                Traveler travelerToUpdate = travelerDAO.getTravelerById(travelerIdToUpdate);
                System.out.print("Enter new Email: ");
                String newEmail = scanner.next();
                System.out.print("Enter new Phone Number: ");
                String newPhoneNumber = scanner.next();
                System.out.print("Enter new Address: ");
                String newAddress = scanner.next();

                travelerToUpdate.setEmail(newEmail);
                travelerToUpdate.setPhoneNumber(newPhoneNumber);
                travelerToUpdate.setAddress(newAddress);

                travelerDAO.updateTraveler(travelerToUpdate);
                System.out.println("Traveler updated successfully!");
                break;

            case 4:
                System.out.print("Enter Traveler ID to delete: ");
                int travelerIdToDelete = scanner.nextInt();
                travelerDAO.deleteTraveler(travelerIdToDelete);
                System.out.println("Traveler deleted successfully!");
                break;

            case 5:
                List<Traveler> travelers = travelerDAO.getAllTravelers();
                System.out.println("All Travelers:");
                for (Traveler trvlr : travelers) {
                    System.out.println("Traveler ID: " + trvlr.getTravelerId() +
                            ", Name: " + trvlr.getName() +
                            ", Email: " + trvlr.getEmail() +
                            ", Phone: " + trvlr.getPhoneNumber() +
                            ", Address: " + trvlr.getAddress());
                }
                break;

            default:
                System.out.println("Invalid choice!");
        }
    } catch (TravelerNotFoundException e) {
        System.out.println(e.getMessage());
    }
}


    
    
    
    
    
    

private static void manageClaims(ClaimDAO claimDAO, Scanner scanner) {
    System.out.println("===== Claim Management =====");
    System.out.println("1. Submit a new claim");
    System.out.println("2. View claim details");
    System.out.println("3. Update claim information");
    System.out.println("4. Delete a claim");
    System.out.println("5. List all claims");
    System.out.print("Enter your choice: ");
    int choice = scanner.nextInt();

    switch (choice) {
        case 1:
            System.out.print("Enter Policy ID: ");
            int policyId = scanner.nextInt();
            System.out.print("Enter Traveler ID: ");
            int travelerId = scanner.nextInt();
            System.out.print("Enter Claim Date: ");
            String claimDate = scanner.next(); // Assuming date as string for this implementation
            System.out.print("Enter Status (submitted/processed): ");
            String status = scanner.next();

            Claim newClaim = new Claim(policyId, travelerId, claimDate, status);
            int claimId = claimDAO.addClaim(newClaim);
            System.out.println("Claim submitted successfully! Claim ID: " + claimId);
            break;

        case 2:
            System.out.print("Enter Claim ID: ");
            claimId = scanner.nextInt();
            Claim claim = claimDAO.getClaimById(claimId);
            if (claim != null) {
                System.out.println("Claim ID: " + claim.getClaimId());
                System.out.println("Policy ID: " + claim.getPolicyId());
                System.out.println("Traveler ID: " + claim.getTravelerId());
                System.out.println("Claim Date: " + claim.getClaimDate());
                System.out.println("Status: " + claim.getStatus());
            } else {
                System.out.println("Claim not found!");
            }
            break;

        case 3:
            System.out.print("Enter Claim ID to update: ");
            claimId = scanner.nextInt();
            claim = claimDAO.getClaimById(claimId);
            if (claim != null) {
                System.out.print("Enter new Claim Date: ");
                claimDate = scanner.next();
                System.out.print("Enter new Status: ");
                status = scanner.next();

                claim.setClaimDate(claimDate);
                claim.setStatus(status);

                claimDAO.updateClaim(claim);
                System.out.println("Claim updated successfully!");
            } else {
                System.out.println("Claim not found!");
            }
            break;

        case 4:
            System.out.print("Enter Claim ID to delete: ");
            claimId = scanner.nextInt();
            claimDAO.deleteClaim(claimId);
            System.out.println("Claim deleted successfully!");
            break;

        case 5:
            List<Claim> claims = claimDAO.getAllClaims();
            System.out.println("All Claims:");
            for (Claim clm : claims) {
                System.out.println("Claim ID: " + clm.getClaimId() + ", Policy ID: " + clm.getPolicyId() +
                        ", Traveler ID: " + clm.getTravelerId() + ", Claim Date: " + clm.getClaimDate() +
                        ", Status: " + clm.getStatus());
            }
            break;

        default:
            System.out.println("Invalid choice!");
    }
}
}